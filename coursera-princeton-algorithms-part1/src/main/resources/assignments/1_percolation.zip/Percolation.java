/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {
    private final int n;
    private final WeightedQuickUnionUF weightedQuickUnionUF;
    private final int topImaginaryIndex;
    private final int bottomImaginaryIndex;
    private int openCount;
    private boolean[] openTracker;

    public Percolation(int n) {
        if (n <= 0)
            throw new IllegalArgumentException(
                    "number of rows and columns can't be equal to or less than 0");
        this.n = n;
        this.openTracker = new boolean[Math.multiplyExact(n, n)];
        topImaginaryIndex = Math.multiplyExact(n, n);
        bottomImaginaryIndex = Math.multiplyExact(n, n) + 1;
        weightedQuickUnionUF = new WeightedQuickUnionUF(Math.multiplyExact(n, n) + 2);
        for (int i = 1; i <= n; i++) {
            weightedQuickUnionUF.union(index(1, i), topImaginaryIndex);
            // weightedQuickUnionUF.union(index(n - 1, i), bottomImaginaryIndex);
        }
    }

    public boolean isOpen(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n)
            throw new IllegalArgumentException("index needs to be between 1 and n");
        return openTracker[index(row, col)];
    }

    private int index(int row, int col) {
        return Math.addExact(Math.multiplyExact(row - 1, n), col - 1);
    }

    public boolean isFull(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n)
            throw new IllegalArgumentException("index needs to be between 1 and n");
        return isOpen(row, col) && weightedQuickUnionUF
                .connected(topImaginaryIndex, index(row, col));
    }

    public void open(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n)
            throw new IllegalArgumentException("index needs to be between 1 and n");
        if (!isOpen(row, col)) {
            int currIndex = index(row, col);
            openTracker[currIndex] = true;
            openCount++;
            if (row > 1 && isOpen(row - 1, col))
                weightedQuickUnionUF.union(index(row - 1, col), currIndex);
            if (col > 1 && isOpen(row, col - 1))
                weightedQuickUnionUF.union(index(row, col - 1), currIndex);
            if (col < n && isOpen(row, col + 1))
                weightedQuickUnionUF.union(index(row, col + 1), currIndex);
            if (row < n && isOpen(row + 1, col))
                weightedQuickUnionUF.union(index(row + 1, col), currIndex);
            if (row == n)
                weightedQuickUnionUF.union(currIndex, bottomImaginaryIndex);

        }
    }

    public int numberOfOpenSites() {
        return openCount;
    }

    public boolean percolates() {
        return weightedQuickUnionUF.connected(bottomImaginaryIndex, topImaginaryIndex);
    }
}
