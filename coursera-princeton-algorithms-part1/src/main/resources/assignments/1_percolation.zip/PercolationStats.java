/* *****************************************************************************
 *  Name:    Alan Turing
 *  NetID:   aturing
 *  Precept: P00
 *
 *  Description:  Prints 'Hello, World' to the terminal window.
 *                By tradition, this is everyone's first program.
 *                Prof. Brian Kernighan initiated this tradition in 1974.
 *
 **************************************************************************** */

import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.StdStats;

public class PercolationStats {
    private static final double ONE_POINT_NINE_SIX = 1.96;
    private Double mean;
    private Double stddev;
    private Double confidenceLo;
    private Double confidenceHi;
    private double[] percolationFractions;
    private final int trials;

    // perform independent trials on an n-by-n grid
    public PercolationStats(int n, int trials) {
        if (n <= 0 || trials <= 0)
            throw new IllegalArgumentException();
        this.trials = trials;
        this.percolationFractions = new double[trials];
        for (int i = 0; i < trials; i++) {
            Percolation percolation = new Percolation(n);
            int openCount = 0;
            while (!percolation.percolates()) {
                int randomX = StdRandom.uniform(1, n + 1);
                int randomY = StdRandom.uniform(1, n + 1);
                if (!percolation.isOpen(randomX, randomY)) {
                    openCount++;
                    percolation.open(randomX, randomY);
                }
            }
            percolationFractions[i] = (openCount * 1.0) / (Math.multiplyExact(n, n));
        }
    }

    // sample mean of percolation threshold
    public double mean() {
        if (mean == null)
            mean = StdStats.mean(percolationFractions);
        return mean;
    }

    // sample standard deviation of percolation threshold
    public double stddev() {
        if (stddev == null)
            stddev = StdStats.stddev(percolationFractions);
        return stddev;
    }

    // low endpoint of 95% confidence interval
    public double confidenceLo() {
        return mean() - ONE_POINT_NINE_SIX * stddev() / Math.sqrt(trials);
    }

    // high endpoint of 95% confidence interval
    public double confidenceHi() {
        return mean() + ONE_POINT_NINE_SIX * stddev() / Math.sqrt(trials);
    }

    // test client (see below)
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        int t = Integer.parseInt(args[1]);
        PercolationStats percolationStats = new PercolationStats(n, t);
        StdOut.println("mean\t\t\t\t\t= " + percolationStats.mean());
        StdOut.println("stddev\t\t\t\t\t= " + percolationStats.stddev());
        StdOut.println("95% confidence interval\t= [" + percolationStats.confidenceLo() + ", "
                               + percolationStats.confidenceHi() + "]");
    }
}
